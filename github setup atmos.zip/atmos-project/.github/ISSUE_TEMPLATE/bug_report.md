---
name: Laporan bug
about: Ada yang tidak jalan
labels: bug
---

**Versi / platform**
(Desktop atau web? Distro Linux atau HP dan browser?)

**Apa yang terjadi**

**Langkah mengulang**
1.
2.

**Pesan error** (kalau ada, tempel dari terminal)
