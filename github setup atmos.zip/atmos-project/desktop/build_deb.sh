#!/usr/bin/env bash
# Build ATMOS -> .deb (x86_64). Jalankan di Linux Mint/Ubuntu/Debian dengan internet (sekali, untuk pip).
set -euo pipefail
VER="${VER:-1.0.0}"
cd "$(dirname "$0")"
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --onedir --windowed --name atmos \
  --exclude-module tkinter --exclude-module matplotlib --exclude-module PyQt5 --exclude-module PyQt6 atmos.py

PKG="build/atmos_${VER}_amd64"
rm -rf "$PKG"
mkdir -p "$PKG/DEBIAN" "$PKG/opt/atmos" "$PKG/usr/bin" "$PKG/usr/share/applications"
cp -r dist/atmos/* "$PKG/opt/atmos/"
ln -s /opt/atmos/atmos "$PKG/usr/bin/atmos"

cat > "$PKG/DEBIAN/control" <<CTRL
Package: atmos
Version: ${VER}
Section: sound
Priority: optional
Architecture: amd64
Depends: libportaudio2, libgl1, libxcb-cursor0
Maintainer: ATMOS <atmos@localhost>
Description: Ubah suara lingkungan menjadi pola visual ambient.
 Proses lokal, tanpa jaringan dan tanpa telemetri.
CTRL

cat > "$PKG/usr/share/applications/atmos.desktop" <<DESK
[Desktop Entry]
Name=ATMOS
Comment=Suara lingkungan menjadi pola visual
Exec=/usr/bin/atmos
Icon=audio-input-microphone
Type=Application
Categories=AudioVideo;Audio;
Terminal=false
DESK

dpkg-deb --build --root-owner-group "$PKG"
echo "Selesai: build/atmos_${VER}_amd64.deb  (pasang: sudo apt install ./build/atmos_${VER}_amd64.deb)"
