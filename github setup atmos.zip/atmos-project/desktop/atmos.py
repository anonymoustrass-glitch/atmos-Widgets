#!/usr/bin/env python3
"""ATMOS: ubah suara sekitar menjadi pola visual. Semua diproses lokal, tanpa jaringan."""
import sys, json, math, random, sqlite3, time, threading
from datetime import datetime
from pathlib import Path

import numpy as np
from scipy.signal import get_window
import sounddevice as sd
import pyqtgraph as pg
from PySide6.QtCore import Qt, QTimer, QSettings, QPointF, QRectF, QByteArray
from PySide6.QtGui import (QPainter, QColor, QPen, QImage, QIcon, QPixmap,
                           QRadialGradient, QOpenGLContext)
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                               QPushButton, QComboBox, QSlider, QFrame, QButtonGroup)
try:
    from PySide6.QtOpenGLWidgets import QOpenGLWidget
except Exception:  # OpenGL tidak tersedia -> otomatis pakai renderer software
    QOpenGLWidget = None

BG, SURFACE, CYAN, VIOLET, TEXT, MUTED = "#080B12", "#111827", "#00E5FF", "#8B5CF6", "#E5E7EB", "#94A3B8"
CFG_FILE = Path.home() / ".config" / "atmos" / "config.json"
DB_FILE = Path.home() / ".local" / "share" / "atmos" / "atmos.db"
DEFAULT_CFG = {"fps": 30, "fft": 2048, "sensitivity_db": 20, "opengl": False, "frameless": False}
PLAY = '<polygon points="6 3 20 12 6 21 6 3"/>'
STOP = '<rect width="14" height="14" x="5" y="5" rx="2"/>'

QSS = f"""
QWidget#root {{ background:{BG}; }}
QWidget {{ color:{TEXT}; font-family:"Inter","Manrope","Noto Sans",sans-serif; font-size:13px; }}
QLabel#title {{ font-size:22px; font-weight:300; letter-spacing:6px; color:{CYAN}; }}
QLabel#muted {{ color:{MUTED}; }}
QFrame#panel {{ background:{SURFACE}; border:1px solid #1f2a3d; border-radius:18px; }}
QPushButton {{ background:{SURFACE}; border:1px solid #1f2a3d; border-radius:16px; padding:8px 18px; }}
QPushButton:hover {{ border-color:{VIOLET}; }}
QPushButton#mode:checked {{ background:{VIOLET}; border-color:{VIOLET}; }}
QPushButton#go {{ background:{CYAN}; color:{BG}; border:none; font-weight:600; padding:9px 22px; }}
QComboBox {{ background:{SURFACE}; border:1px solid #1f2a3d; border-radius:14px; padding:7px 14px; min-width:220px; }}
QComboBox QAbstractItemView {{ background:{SURFACE}; selection-background-color:{VIOLET}; }}
QSlider::groove:horizontal {{ height:4px; background:#1f2a3d; border-radius:2px; }}
QSlider::sub-page:horizontal {{ background:{CYAN}; border-radius:2px; }}
QSlider::handle:horizontal {{ background:{CYAN}; width:14px; margin:-6px 0; border-radius:7px; }}
"""


def icon(body, color=BG):
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" '
           f'stroke="{color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')
    pm = QPixmap(24, 24); pm.fill(Qt.transparent)
    p = QPainter(pm); QSvgRenderer(QByteArray(svg.encode())).render(p); p.end()
    return QIcon(pm)


def load_cfg():
    cfg = dict(DEFAULT_CFG)
    try:
        CFG_FILE.parent.mkdir(parents=True, exist_ok=True)
        if CFG_FILE.exists():
            cfg.update(json.loads(CFG_FILE.read_text()))
        else:
            CFG_FILE.write_text(json.dumps(cfg, indent=2))
    except Exception:
        pass
    return cfg


def log_session(mode, seconds):
    try:
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(DB_FILE) as c:
            c.execute("CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY, started TEXT, seconds REAL, mode TEXT)")
            c.execute("INSERT INTO sessions(started,seconds,mode) VALUES(?,?,?)",
                      (datetime.now().isoformat(timespec="seconds"), round(seconds, 1), mode))
    except Exception:
        pass


class Engine:
    """Tangkap mikrofon -> FFT -> spektrum 0..1 dan tiga pita (rendah, sedang, tinggi)."""
    def __init__(self, n):
        self.n = n
        self.win = get_window("hann", n).astype(np.float32)
        self.buf = np.zeros(n, np.float32)
        self.lock = threading.Lock()
        self.stream = None
        self.spec = np.zeros(n // 2 + 1, np.float32)
        self.bands = np.zeros(3, np.float32)
        self.level = 0.0
        self.masks = None

    @property
    def running(self):
        return self.stream is not None

    def start(self, device):
        sr = int(sd.query_devices(device, "input")["default_samplerate"])
        freqs = np.fft.rfftfreq(self.n, 1 / sr)
        self.masks = [(freqs >= a) & (freqs < b) for a, b in ((40, 250), (250, 2000), (2000, 8000))]
        self.stream = sd.InputStream(device=device, channels=1, samplerate=sr, blocksize=512, callback=self._cb)
        self.stream.start()

    def stop(self):
        if self.stream:
            self.stream.stop(); self.stream.close(); self.stream = None
        with self.lock:
            self.buf[:] = 0

    def _cb(self, indata, frames, t, status):
        x = indata[:, 0]; k = min(len(x), self.n)
        with self.lock:
            self.buf[:-k] = self.buf[k:]
            self.buf[-k:] = x[-k:]

    def analyse(self, gain_db):
        with self.lock:
            x = self.buf.copy()
        mag = np.abs(np.fft.rfft(x * self.win)) * (2 / self.n)
        norm = np.clip((20 * np.log10(mag + 1e-9) + 80 + gain_db) / 70, 0, 1).astype(np.float32)
        self.spec += (norm - self.spec) * 0.4
        if self.masks:
            tgt = np.array([self.spec[m].mean() for m in self.masks], np.float32)
            self.bands += (tgt - self.bands) * 0.25
        self.level = float(self.bands.mean())
        return x[-512:]


def mix(v):
    a, b, t = ((8, 11, 18), (139, 92, 246), v * 2) if v < .5 else ((139, 92, 246), (0, 229, 255), (v - .5) * 2)
    return QColor(*[int(a[i] + (b[i] - a[i]) * t) for i in range(3)])


class Scene:
    """Logika gambar. Dirender ke buffer setengah resolusi supaya ringan di CPU."""
    def setup(self, eng):
        self.eng, self.mode, self.rip, self.spin, self.buf = eng, "Hujan", [], 0.0, None
        self.rows = 72
        e = np.geomspace(2, 370, self.rows + 1).astype(int)
        self.edges = [(int(e[i]), int(max(e[i + 1], e[i] + 1))) for i in range(self.rows)]

    def set_mode(self, m):
        self.mode = m; self.rip.clear(); self.buf = None

    def render_scene(self):
        bw, bh = max(2, self.width() // 2), max(2, self.height() // 2)
        if self.buf is None or self.buf.width() != bw or self.buf.height() != bh:
            self.buf = QImage(bw, bh, QImage.Format_ARGB32_Premultiplied); self.buf.fill(QColor(BG))
        bp = QPainter(self.buf); bp.setRenderHint(QPainter.Antialiasing)
        getattr(self, "draw_" + self.mode)(bp, bw, bh); bp.end()
        p = QPainter(self); p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(self.rect(), self.buf); p.end()

    def draw_Hujan(self, p, w, h):
        p.fillRect(0, 0, w, h, QColor(8, 11, 18, 26))
        b, sc = self.eng.bands, min(w, h) / 130
        for _ in range(int(b[2] ** 2 * 9 + b[1] * 1.5)):
            self.rip.append([random.random() * w, random.random() * h, 2.0,
                             (30 + random.random() * 90) * sc * (.5 + self.eng.level * 1.2) / 2, 1.0])
        alive = []
        for r in self.rip:
            r[2] += (r[3] - r[2]) * .06 + .3; r[4] *= .95
            if r[4] < .03:
                continue
            p.setPen(QPen(QColor(0, 229, 255, int(r[4] * 230)), 1.2))
            p.drawEllipse(QPointF(r[0], r[1]), r[2], r[2] * .42)
            if r[2] > 8:
                p.setPen(QPen(QColor(139, 92, 246, int(r[4] * 120)), 1.0))
                p.drawEllipse(QPointF(r[0], r[1]), r[2] * .6, r[2] * .25)
            alive.append(r)
        self.rip = alive[-500:]

    def draw_Kipas(self, p, w, h):
        p.fillRect(0, 0, w, h, QColor(8, 11, 18, 40))
        b = self.eng.bands
        self.spin += .004 + b[0] * .16 + b[1] * .05
        cx, cy, R = w / 2, h / 2, min(w, h) * .44
        for ring in range(4):
            rr, amp = R * (.35 + ring * .2), .16 + b[1] * .5 + ring * .03
            col = QColor(0, 229, 255) if ring % 2 == 0 else QColor(139, 92, 246)
            col.setAlpha(int(70 + min(1, float(b[ring % 2]) * 1.5) * 170))
            p.setPen(QPen(col, 1.2))
            for k in range(5):
                a = self.spin * (1 if ring % 2 == 0 else -.7) + k * 2 * math.pi / 5 + ring * .4
                p.save(); p.translate(cx, cy); p.rotate(math.degrees(a))
                p.drawEllipse(QPointF(rr * .5, 0), rr * .5, rr * amp); p.restore()
        g = QRadialGradient(cx, cy, R * .25)
        g.setColorAt(0, QColor(0, 229, 255, int(120 + b[0] * 130))); g.setColorAt(1, QColor(0, 229, 255, 0))
        p.setPen(Qt.NoPen); p.setBrush(g); p.drawEllipse(QPointF(cx, cy), R * .25, R * .25)

    def draw_Jalan(self, p, w, h):
        st = 2
        p.drawImage(-st, 0, self.buf.copy())
        hh, spec = h / self.rows, self.eng.spec
        for i, (a, b) in enumerate(self.edges):
            p.fillRect(QRectF(w - st, h - (i + 1) * hh, st, hh + 1), mix(float(spec[a:b].max())))


def make_canvas(eng, use_gl):
    if use_gl:
        class C(Scene, QOpenGLWidget):
            def paintGL(self): self.render_scene()
    else:
        class C(Scene, QWidget):
            def paintEvent(self, e): self.render_scene()
    c = C(); c.setup(eng); return c


class Main(QWidget):
    MODES = ["Hujan", "Kipas", "Jalan"]

    def __init__(self, cfg, use_gl):
        super().__init__()
        self.setObjectName("root"); self.setWindowTitle("ATMOS"); self.resize(1100, 720); self.setMinimumSize(720, 520)
        self.frameless = bool(cfg["frameless"] or "--frameless" in sys.argv)
        if self.frameless:
            self.setWindowFlag(Qt.FramelessWindowHint)
        self.qs, self.t0 = QSettings("atmos", "atmos"), None
        self.eng = Engine(int(cfg["fft"]))

        root = QVBoxLayout(self); root.setContentsMargins(18, 14, 18, 14); root.setSpacing(12)
        head = QHBoxLayout(); head.setSpacing(8)
        title = QLabel("ATMOS"); title.setObjectName("title"); head.addWidget(title); head.addSpacing(16)
        self.grp = QButtonGroup(self)
        saved = self.qs.value("mode", "Hujan")
        for m in self.MODES:
            b = QPushButton(m); b.setObjectName("mode"); b.setCheckable(True); b.setChecked(m == saved)
            b.clicked.connect(lambda _, m=m: self.canvas.set_mode(m)); self.grp.addButton(b); head.addWidget(b)
        head.addStretch(1)
        self.dev = QComboBox()
        try:
            for i, d in enumerate(sd.query_devices()):
                if d["max_input_channels"] > 0:
                    self.dev.addItem(d["name"], i)
        except Exception:
            pass
        idx = self.dev.findText(self.qs.value("device", ""))
        if idx >= 0:
            self.dev.setCurrentIndex(idx)
        self.btn = QPushButton(" Mulai"); self.btn.setObjectName("go"); self.btn.setIcon(icon(PLAY))
        self.btn.clicked.connect(self.toggle)
        head.addWidget(self.dev); head.addWidget(self.btn)
        if self.frameless:
            x = QPushButton("✕"); x.clicked.connect(self.close); head.addWidget(x)
        root.addLayout(head)

        panel = QFrame(); panel.setObjectName("panel")
        pl = QVBoxLayout(panel); pl.setContentsMargins(6, 6, 6, 6)
        self.canvas = make_canvas(self.eng, use_gl); self.canvas.set_mode(saved if saved in self.MODES else "Hujan")
        pl.addWidget(self.canvas); root.addWidget(panel, 1)

        self.plot = pg.PlotWidget(background=None); self.plot.setFixedHeight(70)
        for ax in ("left", "bottom"):
            self.plot.hideAxis(ax)
        self.plot.setYRange(-1, 1); self.plot.setMouseEnabled(False, False)
        self.plot.setMenuEnabled(False); self.plot.hideButtons()
        self.curve = self.plot.plot(pen=pg.mkPen(CYAN, width=2)); root.addWidget(self.plot)

        foot = QHBoxLayout()
        self.status = QLabel("Siap. Pilih mikrofon lalu tekan Mulai." if self.dev.count() else "Mikrofon tidak ditemukan.")
        self.status.setObjectName("muted"); foot.addWidget(self.status, 1)
        lab = QLabel("Sensitivitas"); lab.setObjectName("muted"); foot.addWidget(lab)
        self.sl = QSlider(Qt.Horizontal); self.sl.setRange(0, 40); self.sl.setFixedWidth(180)
        self.sl.setValue(int(self.qs.value("gain", cfg["sensitivity_db"]))); foot.addWidget(self.sl)
        root.addLayout(foot)

        self.timer = QTimer(self); self.timer.timeout.connect(self.tick)
        self.timer.start(int(1000 / max(10, int(cfg["fps"]))))

    def tick(self):
        wave = self.eng.analyse(self.sl.value())
        self.canvas.update()
        self.curve.setData(np.clip(wave * 4, -1, 1))

    def toggle(self):
        if self.eng.running:
            return self.stop()
        try:
            self.eng.start(self.dev.currentData())
        except Exception as e:
            self.status.setText(f"Mikrofon gagal dibuka: {e}"); return
        self.t0 = time.time(); self.btn.setText(" Berhenti"); self.btn.setIcon(icon(STOP))
        self.status.setText("Mendengarkan… audio hanya diproses di perangkat ini.")

    def stop(self):
        if self.t0:
            log_session(self.canvas.mode, time.time() - self.t0); self.t0 = None
        self.eng.stop(); self.btn.setText(" Mulai"); self.btn.setIcon(icon(PLAY)); self.status.setText("Berhenti.")

    def mousePressEvent(self, e):
        if self.frameless and e.position().y() < 60 and self.windowHandle():
            self.windowHandle().startSystemMove()

    def closeEvent(self, e):
        self.stop()
        self.qs.setValue("mode", self.canvas.mode); self.qs.setValue("device", self.dev.currentText())
        self.qs.setValue("gain", self.sl.value()); super().closeEvent(e)


def main():
    app = QApplication(sys.argv); app.setStyleSheet(QSS); cfg = load_cfg()
    use_gl = False
    if cfg["opengl"] and QOpenGLWidget is not None:
        try:
            use_gl = QOpenGLContext().create()
        except Exception:
            use_gl = False
    w = Main(cfg, use_gl); w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
