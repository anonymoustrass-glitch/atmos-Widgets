# ATMOS

Ubah suara lingkungan yang ditangkap mikrofon (hujan, kipas, suasana jalan) menjadi pola visual ambient.
Semua diproses di perangkat sendiri: tanpa cloud, tanpa telemetri.

```
atmos-project/
├── desktop/   # Linux desktop (Python, PySide6)
└── web/       # Versi web/PWA satu file (bisa dijadikan APK Android)
```

## Desktop (Linux Mint / Ubuntu / Debian, x86_64)

```bash
cd desktop
sudo apt install python3-venv libportaudio2 libxcb-cursor0
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python3 atmos.py            # tambahkan --frameless untuk jendela tanpa bingkai
```

Bangun paket `.deb`:

```bash
cd desktop
./build_deb.sh
sudo apt install ./build/atmos_1.0.0_amd64.deb
```

Pengaturan ada di `~/.config/atmos/config.json` (`fps`, `fft`, `sensitivity_db`, `opengl`, `frameless`).
Riwayat sesi disimpan lokal di `~/.local/share/atmos/atmos.db`.

## Web / Android

`web/index.html` adalah satu file tanpa dependensi. Mikrofon di browser hanya jalan lewat HTTPS.

1. Aktifkan **GitHub Pages** (Settings → Pages → Deploy from branch → folder `/web` atau pindahkan isinya ke root).
2. Buka link-nya di Chrome Android → menu ⋮ → **Tambahkan ke layar utama**.
3. Untuk file `.apk`, masukkan link tadi ke [pwabuilder.com](https://www.pwabuilder.com) dan pilih Android.

## Pola

| Pola  | Respons                                        |
|-------|------------------------------------------------|
| Hujan | Riak muncul makin banyak saat suara tinggi kuat |
| Kipas | Baling-baling berputar mengikuti dengung rendah |
| Jalan | Spektrogram warna bergulir ke kiri              |

## Otomatisasi GitHub

- **Web**: setiap perubahan di `web/` otomatis di-deploy ke GitHub Pages (`.github/workflows/pages.yml`).
  Aktifkan sekali di Settings → Pages → Source: **GitHub Actions**.
- **.deb**: buat tag, misalnya `git tag v1.0.0 && git push origin v1.0.0`. File `.deb` akan dibangun dan
  dilampirkan otomatis di halaman Releases (`.github/workflows/build-deb.yml`).

## Lisensi

MIT. Lihat `LICENSE`.
